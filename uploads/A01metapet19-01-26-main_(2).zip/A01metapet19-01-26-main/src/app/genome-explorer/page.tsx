'use client';

import MetaPetGenomeExplorer from '@/components/MetaPetGenomeExplorer';

const GenomeExplorerPage = () => {
  return <MetaPetGenomeExplorer />;
};

export default GenomeExplorerPage;
