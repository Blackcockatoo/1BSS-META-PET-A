export { decodeGenome, getTraitSummary } from '@metapet/core/genome';
