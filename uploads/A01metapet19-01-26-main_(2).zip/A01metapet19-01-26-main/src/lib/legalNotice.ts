export const LEGAL_NOTICE_TEXT =
  "All Jewble branding and creative IP remains the property of Blue Snake Studios; the school receives a limited educational-use license.";

export const getLegalNoticeYear = () => new Date().getFullYear();
