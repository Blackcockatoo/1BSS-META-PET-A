import { JewbleLoadingScreen } from "@/components/JewbleLoadingScreen";

export default function Loading() {
  return <JewbleLoadingScreen />;
}
