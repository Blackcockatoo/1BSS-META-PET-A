export const FEATURES = {
  MOCK_MODE: false,
  IDENTITY: true,
  ECC_PROFILE: '6x7' as const,
  AUDIO: true,
  TICK: true,
  BACKGROUND_PAUSE: true,
  LOW_POWER_TICK_MS: 2000,
};
