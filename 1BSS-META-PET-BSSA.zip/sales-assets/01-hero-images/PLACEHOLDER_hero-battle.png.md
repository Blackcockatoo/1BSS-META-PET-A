# Hero Battle Screenshot

## What to Capture
Battle arena during or just after a victory moment.

## Key Elements
- Battle arena UI visible
- Opponent name displayed (e.g., "Crystal Phoenix")
- Victory message or win animation
- Energy shield indicator
- Streak counter if applicable

## Recommended State
Win a battle and capture the victory moment

## Dimensions
1920x1080 or 1242x2688

## Usage
Showcasing competitive gameplay and consciousness duels
