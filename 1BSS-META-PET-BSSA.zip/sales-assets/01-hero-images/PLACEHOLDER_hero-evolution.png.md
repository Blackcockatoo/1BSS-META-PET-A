# Hero Evolution Screenshot

## What to Capture
Pet in QUANTUM or SPECIATION stage with evolution panel visible.

## Key Elements
- Pet showing evolved form (visual differences from base)
- Evolution panel showing current stage
- Stage progression indicators
- Any evolved cosmetics or effects

## Recommended State
Requires pet at advanced evolution stage

## Dimensions
1920x1080 or 1242x2688

## Usage
Demonstrating long-term progression and growth
