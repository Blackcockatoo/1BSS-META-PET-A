# Hero Consciousness Screenshot

## What to Capture
Pet displaying a distinct emotional state with response bubble visible.

## Key Elements
- Pet showing playful, ecstatic, or affectionate state
- Response bubble with emotional text visible
- Particle field reflecting the emotional state
- Vitals panel showing connection between stats and mood

## Recommended State
Play with pet multiple times to trigger "ecstatic" state

## Dimensions
1920x1080 or 1242x2688

## Usage
Showcasing the consciousness system - "Your pet actually feels"
